--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Homebrew)
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE treesdb_02;
--
-- Name: treesdb_02; Type: DATABASE; Schema: -; Owner: alexis
--

CREATE DATABASE treesdb_02 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE treesdb_02 OWNER TO alexis;

\connect treesdb_02

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: trees; Type: TABLE; Schema: public; Owner: alexis
--

CREATE TABLE public.trees (
    idbase integer,
    location_type character varying,
    domain character varying,
    arrondissement character varying,
    suppl_address character varying,
    number character varying,
    address character varying,
    id_location character varying,
    name character varying,
    genre character varying,
    species character varying,
    variety character varying,
    circumference integer,
    height integer,
    stage character varying,
    geo_point_2d character varying,
    remarquable boolean
);


ALTER TABLE public.trees OWNER TO alexis;

--
-- Name: version; Type: TABLE; Schema: public; Owner: alexis
--

CREATE TABLE public.version (
    id integer NOT NULL,
    version text NOT NULL,
    description text NOT NULL,
    current boolean DEFAULT false NOT NULL
);


ALTER TABLE public.version OWNER TO alexis;

--
-- Name: version_id_seq; Type: SEQUENCE; Schema: public; Owner: alexis
--

CREATE SEQUENCE public.version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.version_id_seq OWNER TO alexis;

--
-- Name: version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alexis
--

ALTER SEQUENCE public.version_id_seq OWNED BY public.version.id;


--
-- Name: version id; Type: DEFAULT; Schema: public; Owner: alexis
--

ALTER TABLE ONLY public.version ALTER COLUMN id SET DEFAULT nextval('public.version_id_seq'::regclass);


--
-- Data for Name: trees; Type: TABLE DATA; Schema: public; Owner: alexis
--

COPY public.trees (idbase, location_type, domain, arrondissement, suppl_address, number, address, id_location, name, genre, species, variety, circumference, height, stage, geo_point_2d, remarquable) FROM stdin;
\.
COPY public.trees (idbase, location_type, domain, arrondissement, suppl_address, number, address, id_location, name, genre, species, variety, circumference, height, stage, geo_point_2d, remarquable) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: alexis
--

COPY public.version (id, version, description, current) FROM stdin;
\.
COPY public.version (id, version, description, current) FROM '$$PATH$$/3664.dat';

--
-- Name: version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alexis
--

SELECT pg_catalog.setval('public.version_id_seq', 1, true);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: public; Owner: alexis
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

